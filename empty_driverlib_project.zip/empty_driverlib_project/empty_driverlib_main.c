//
// Included Files
//
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "can_communication.h"
//#include "c2000ware_libraries.h"

void CAN_init();

uint32_t counter = 0;
uint16_t txArray[8];
uint16_t txArray2[8];
uint16_t j = 0;
uint16_t rxMsgData[8];
uint16_t rxMsgData2[8];
uint16_t i = 0;
uint32_t msgID1[1];
uint32_t msgID2[1];

CAN_MsgFrameType frame[2];

//
// Main
//
void main(void)
{

    //
    // Initialize device clock and peripherals
    //
    Device_init();

    //
    // Disable pin locks and enable internal pull-ups.
    //
    Device_initGPIO();

    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    //
    // PinMux and Peripheral Initialization
    //
    Board_init();
    CAN_init();
    //
    // Enable Global Interrupt (INTM) and real time interrupt (DBGM)
    //
    EINT;
    ERTM;

    while(1)
    {
        if(counter % (uint32_t)50 == (uint32_t)0U)
            {
               //packTransmitMessages();
               receiveCanMessages();
            }


//            if(counter % (uint32_t)100 == (uint32_t)0U)
//            {
//                i = 60;
//                for(j = 0; j < 8; j++)
//                   {
//                       txArray2[j] = i++;
//                   }
//
//                   CAN_sendMessage(CANA_BASE,2,8,txArray2);
//                   receiveCanMessages();
                  // CAN_readMessageWithID(CANA_BASE, (uint32_t)4U, frame , msgID2, rxMsgData2);
                  // CAN_readMessage(CANA_BASE, (uint32_t)2, rxMsgData2);

//                   for(j =0; j< 8; j++)
//                     {
//                         txArray2[j] = 0;
//                     }

//            }

        
    }
}


/* Timer Interrupt */
__interrupt void INT_myCPUTIMER0_ISR ()
{
   counter++;
   Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}



//
// End of File
//
