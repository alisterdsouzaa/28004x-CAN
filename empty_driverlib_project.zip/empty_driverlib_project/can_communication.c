/*
 * can_communication.c
 *
 *  Created on: 04-Oct-2024
 *      Author: alister
 */

#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "can_communication.h"

rx_msgs_struct rx;
tx_msgs_struct tx;

#define DEVICE_GPIO_PIN_CANRXA      (33U)                   // GPIO number for CAN RX
#define DEVICE_GPIO_PIN_CANTXA      (32U)                   // GPIO number for CAN TX
#define DEVICE_GPIO_CFG_CANTXA      (GPIO_32_CANA_TX)       // "pinConfig" for CANA TX
#define DEVICE_GPIO_CFG_CANRXA      (GPIO_33_CANA_RX)       // "pinConfig" for CANA RX

uint32_t canBaudRate = 500;
uint32_t messageID[1];
uint16_t rxMsgDatas[8];
uint16_t canFaultError = 0;
uint32_t canReceiveBuffer[9];
uint16_t resultFlag = 0;
uint32_t Idx = 0, Indx = 0;

CAN_MsgFrameType frameType[2];

void CAN_init(){

    canBaudRate = canBaudRate * 1000;

    GPIO_setPinConfig(DEVICE_GPIO_CFG_CANRXA);
    GPIO_setPinConfig(DEVICE_GPIO_CFG_CANTXA);

    CAN_initModule(CANA_BASE);
    CAN_setBitRate(CANA_BASE, DEVICE_SYSCLK_FREQ, canBaudRate, 20);

//    CAN_enableTestMode(CANA_BASE, CAN_TEST_LBACK);
//
//    CAN_enableAutoBusOn(CANA_BASE);
//    CAN_setAutoBusOnTime(CANA_BASE, 0);

    /* Setting Message Objects */
    //CAN_setupMessageObject(CANA_BASE, 1, 0x1312, CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(CANA_BASE, 3, 0x1313, CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);

    /*RX msg obj setup */
    CAN_setupMessageObject(CANA_BASE, 2, 0x1314, CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_RX, 0x1FFFFFFF, 0,8);
    CAN_setupMessageObject(CANA_BASE, 1, 0x1315, CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_RX, 0x1FFFFFFF, 0,8);
    CAN_setupMessageObject(CANA_BASE, 4, 0x1316, CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_RX, 0x1FFFFFFF, 0,8);


    CAN_startModule(CANA_BASE);
}

/*  packs and sends Tx messages */
void packTransmitMessages()
{
    /* in this msg will be transmitted at desired frequencies */
    tx.message1.data.element1 = 1;     /* 1 byte */
    tx.message1.data.element2 = 2;     /* 1 byte */
    tx.message1.data.element3 = 3;     /* 1 byte */
    tx.message1.data.element4 = 4;     /* 1 byte */
    tx.message1.data.element5 = 5;     /* 1 byte */
    tx.message1.data.element6 = 6;     /* 1 byte */
    tx.message1.data.element7 = 7;     /* 1 byte */
    tx.message1.data.element8 = 8;     /* 1 byte */

    CAN_sendMessage(CANA_BASE,  3,  8,  tx.message1.array);



   // CAN_readMessage(CANA_BASE, 1, rxMsgData);
    //CAN_readMessageWithID(CANA_BASE, (uint32_t)1U, frame , msgID1, rxMsgData);

}


/* Rx CAN Messages and ERR/Fault Checks */
void receiveCanMessages()
{
    uint32_t status = 0;
    for(Idx=1;Idx<5;Idx++)
    {
        resultFlag = CAN_readMessageWithID(CANA_BASE,Idx,frameType,messageID,rxMsgDatas);
        if(resultFlag)
        {
            /* get Message ID */
            canReceiveBuffer[0] = messageID[0];
            for(Indx = 1;Indx<9;Indx++)
            {
                canReceiveBuffer[Indx] = rxMsgDatas[Indx-1];
            }
            resultFlag = 0;
            /*clear Rx Array*/
            for(Indx = 1;Indx<9;Indx++)
            {
                rxMsgDatas[Indx] =0;
            }

            extractRXmsg();
        }
    }
        /* checking Errors */
        status = CAN_getStatus(CANA_BASE);
        if ( (status & CAN_STATUS_PERR) || (status & CAN_STATUS_BUS_OFF) ||
                (status & CAN_STATUS_EWARN) || (status & CAN_STATUS_EPASS) )
        {
            canFaultError |= (1 << 0);
        }

}

void extractRXmsg(void)
{
    /* Based on MsgID Rx messages are extracted and populated into respective Arrays */
    if(canReceiveBuffer[0] == 0x1314)
    {
        for(Idx=0; Idx<8;Idx++)
        {
            rx.message1.array[Idx] = canReceiveBuffer[Idx+1];
        }

        /* Clear the buff */
        for(Idx=0; Idx<9; Idx++)
        {
            canReceiveBuffer[Idx] = 0;
        }
    }
    if(canReceiveBuffer[0] == 0x1315)
    {
        for(Idx=0; Idx<8;Idx++)
        {
            rx.message2.array[Idx] = canReceiveBuffer[Idx+1];
        }

        for(Idx=0; Idx<9; Idx++)
        {
            canReceiveBuffer[Idx] = 0;
        }
    }

    if(canReceiveBuffer[0] == 0x1316)
    {
        for(Idx=0; Idx<8;Idx++)
        {
            rx.message3.array[Idx] = canReceiveBuffer[Idx+1];
        }

        for(Idx=0; Idx<9; Idx++)
        {
            canReceiveBuffer[Idx] = 0;
        }
    }

}


uint16_t getCanFaults()
{
    return canFaultError;
}


