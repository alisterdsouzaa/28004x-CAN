/*
 * can_communication.h
 *
 *  Created on: 04-Oct-2024
 *      Author: alister
 */

#ifndef CAN_COMMUNICATION_H_
#define CAN_COMMUNICATION_H_

#define DLC (8U)

/* Rx Message 1 Structure */
typedef struct
{
    uint16_t throttleMSB;
    uint16_t throttleLSB;
    uint16_t reserved;
    uint16_t reserved1;

}rx_msg1;

typedef union
{
    rx_msg1 data;
    uint16_t array[DLC];
}rx_msg1_u;


/* Rx Message 2 Structure */
typedef struct
{
    uint16_t element1;
    uint16_t element2;
    uint16_t reserved;
    uint16_t reserved1;

}rx_msg2;

typedef union
{
    rx_msg2 data;
    uint16_t array[DLC];
}rx_msg2_u;


/* Rx Message 3 Structure */
typedef struct
{
    uint16_t element1;
    uint16_t element2;
    uint16_t element3;
    uint16_t element4;
    uint16_t element5;
    uint16_t element6;
    uint16_t element7;
    uint16_t element8;

}rx_msg3;

typedef union
{
    rx_msg3 data;
    uint16_t array[DLC];
}rx_msg3_u;


/* Universal Structure for Rx Msg Access */
typedef struct
{
    rx_msg1_u message1;
    rx_msg2_u message2;
    rx_msg3_u message3;

}rx_msgs_struct;

/*
 * -----------------------------Transmit messages-------------------------------------------------/
 */

/* Tx Message 1 Structure */

typedef struct
{
    uint16_t element1;
    uint16_t element2;
    uint16_t element3;
    uint16_t element4;
    uint16_t element5;
    uint16_t element6;
    uint16_t element7;
    uint16_t element8;

}tx_msg1;

typedef union
{
    tx_msg1 data;
    uint16_t array[DLC];
}tx_msg1_u;

/* Universal Structure for Tx Msg Access */
typedef struct
{
    tx_msg1_u message1;
    //tx_msg2_u message2;

}tx_msgs_struct;


void CAN_init();
void packTransmitMessages();
void receiveCanMessages();
void extractRXmsg(void);




#endif /* CAN_COMMUNICATION_H_ */
